#!/bin/sh

cd MPlayer-1.0rc3/
make clean
