#!/bin/sh

rm -f to-compress.rar
rm -rf to-compress
