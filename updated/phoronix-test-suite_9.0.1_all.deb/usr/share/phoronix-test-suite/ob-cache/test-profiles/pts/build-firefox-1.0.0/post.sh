#!/bin/sh

rm -rf firefox/
rm -rf mozilla-release/