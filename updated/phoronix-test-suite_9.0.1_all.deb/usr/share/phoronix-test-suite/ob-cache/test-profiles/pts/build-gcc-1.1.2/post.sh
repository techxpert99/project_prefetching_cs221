#!/bin/sh

rm -rf gcc-8.2.0
