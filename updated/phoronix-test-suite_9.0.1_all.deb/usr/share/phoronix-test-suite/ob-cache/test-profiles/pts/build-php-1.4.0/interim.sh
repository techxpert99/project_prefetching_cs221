#!/bin/sh

cd php-7.1.9/
make clean
