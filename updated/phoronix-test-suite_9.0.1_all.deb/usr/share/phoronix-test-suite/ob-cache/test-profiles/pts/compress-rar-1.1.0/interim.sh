#!/bin/sh

rm -f to-compress.rar