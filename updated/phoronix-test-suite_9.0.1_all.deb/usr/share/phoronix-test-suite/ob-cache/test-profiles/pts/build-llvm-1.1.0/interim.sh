#!/bin/sh

cd build
make clean
